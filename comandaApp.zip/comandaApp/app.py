from flask import Flask
from config import Config
from extensions import db
from blueprints.main import main_bp
from blueprints.cardapio import cardapio_bp
from blueprints.comandas import comandas_bp

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)

    app.register_blueprint(main_bp)
    app.register_blueprint(cardapio_bp, url_prefix="/cardapio")
    app.register_blueprint(comandas_bp, url_prefix="/comandas")

    with app.app_context():
        db.create_all()

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=5000, debug=True)
