from flask import Blueprint, render_template, request, redirect, url_for, flash
from extensions import db
from models import ItemCardapio

cardapio_bp = Blueprint("cardapio", __name__, template_folder="../templates")

@cardapio_bp.route("/")
def list_cardapio():
    itens = ItemCardapio.query.order_by(ItemCardapio.categoria, ItemCardapio.nome).all()
    return render_template("cardapio_list.html", itens=itens)

@cardapio_bp.route("/novo", methods=["GET", "POST"])
def novo_item():
    if request.method == "POST":
        nome = request.form["nome"]
        categoria = request.form.get("categoria")
        preco = request.form["preco"]
        try:
            preco = float(preco)
        except:
            flash("Preço inválido", "danger")
            return redirect(url_for(".novo_item"))
        item = ItemCardapio(nome=nome, categoria=categoria, preco=preco)
        db.session.add(item)
        db.session.commit()
        flash("Item criado", "success")
        return redirect(url_for(".list_cardapio"))
    return render_template("cardapio_form.html", item=None)

@cardapio_bp.route("/editar/<int:item_id>", methods=["GET", "POST"])
def editar_item(item_id):
    item = ItemCardapio.query.get_or_404(item_id)
    if request.method == "POST":
        item.nome = request.form["nome"]
        item.categoria = request.form.get("categoria")
        try:
            item.preco = float(request.form["preco"])
        except:
            flash("Preço inválido", "danger")
            return redirect(url_for(".editar_item", item_id=item.id))
        db.session.commit()
        flash("Item atualizado", "success")
        return redirect(url_for(".list_cardapio"))
    return render_template("cardapio_form.html", item=item)

@cardapio_bp.route("/excluir/<int:item_id>", methods=["POST"])
def excluir_item(item_id):
    item = ItemCardapio.query.get_or_404(item_id)
    db.session.delete(item)
    db.session.commit()
    flash("Item excluído", "success")
    return redirect(url_for(".list_cardapio"))
