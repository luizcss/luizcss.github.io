from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file
from extensions import db
from models import Comanda, ItemCardapio, ComandaItem
import qrcode
import io
import base64
import csv
from datetime import date
from datetime import datetime

comandas_bp = Blueprint("comandas", __name__, template_folder="../templates")

@comandas_bp.route("/")
def listar_comandas():
    comandas = Comanda.query.order_by(Comanda.created_at.desc()).all()
    return render_template("comandas_list.html", comandas=comandas)

@comandas_bp.route("/nova", methods=["POST"])
def nova_comanda():
    # gerar número simples sequencial ou timestamp
    now = datetime.now()
    numero = f"C-{now.year}{now.hour}{now.minute}{now.second}{int(+Comanda.query.count())+1}"
    # numero = request.form.get("numero") or f"C-2025-{int(+Comanda.query.count())+1}"
    cliente = request.form.get("cliente")
    com = Comanda(numero=numero, cliente=cliente, status="Aberta")
    db.session.add(com)
    db.session.commit()
    flash("Comanda criada", "success")
    return redirect(url_for(".listar_comandas"))

@comandas_bp.route("/<int:comanda_id>", methods=["GET", "POST"])
def ver_comanda(comanda_id):
    com = Comanda.query.get_or_404(comanda_id)
    itens_cardapio = ItemCardapio.query.all()

    # adicionar item à comanda
    if request.method == "POST" and request.form.get("action") == "add_item":
        item_id = int(request.form["item_id"])
        quantidade = int(request.form.get("quantidade", 1))
        item = ItemCardapio.query.get_or_404(item_id)
        ci = ComandaItem(
            comanda=com,
            item=item,
            item_id=item.id,
            quantidade=quantidade,
            preco_unitario=item.preco
        )
        db.session.add(ci)
        db.session.commit()
        flash("Item adicionado", "success")
        return redirect(url_for(".ver_comanda", comanda_id=com.id))

    # encerrar comanda
    if request.method == "POST" and request.form.get("action") == "encerrar":
        com.status = "Encerrada"
        db.session.commit()
        flash("Comanda encerrada", "info")
        return redirect(url_for(".ver_comanda", comanda_id=com.id))

    # marcar como paga
    if request.method == "POST" and request.form.get("action") == "pagar":
        com.status = "Paga"
        db.session.commit()
        flash("Comanda paga", "success")
        return redirect(url_for(".ver_comanda", comanda_id=com.id))

    # remover item
    if request.method == "POST" and request.form.get("action") == "remover_item":
        item_id = int(request.form.get("comanda_item_id"))
        ci = ComandaItem.query.get_or_404(item_id)
        db.session.delete(ci)
        db.session.commit()
        flash("Item removido", "warning")
        return redirect(url_for(".ver_comanda", comanda_id=com.id))

    # gerar QR Code em base64 para a comanda (opcional)
    qr_b64 = None
    qr_data = request.url  # ou um endpoint público para acessar a comanda
    img = qrcode.make(qr_data)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    qr_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

    return render_template("comanda_detail.html", com=com, itens_cardapio=itens_cardapio, qr_b64=qr_b64)

@comandas_bp.route("/excluir/<int:comanda_id>", methods=["POST"])
def excluir_comanda(comanda_id):
    com = Comanda.query.get_or_404(comanda_id)
    db.session.delete(com)
    db.session.commit()
    flash("Comanda excluída", "success")
    return redirect(url_for(".listar_comandas"))

@comandas_bp.route("/relatorio_diario")
def relatorio_diario():
    hoje = date.today()
    comandas = Comanda.query.filter(db.func.date(Comanda.created_at) == hoje).all()
    total = sum(c.total for c in comandas)
    return render_template("relatorio.html", comandas=comandas, total=total, data=hoje)

@comandas_bp.route("/relatorio_csv")
def relatorio_csv():
    hoje = date.today().isoformat()
    comandas = Comanda.query.filter(db.func.date(Comanda.created_at) == date.today()).all()
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["numero","cliente","status","total"])
    for c in comandas:
        writer.writerow([c.numero, c.cliente or "", c.status, f"{c.total:.2f}"])
    buf.seek(0)
    return send_file(io.BytesIO(buf.getvalue().encode("utf-8")), mimetype="text/csv", as_attachment=True, download_name=f"relatorio_{hoje}.csv")
