from datetime import datetime
from extensions import db

class Comanda(db.Model):
    __tablename__ = "comandas"
    id = db.Column(db.Integer, primary_key=True)
    numero = db.Column(db.String(200), unique=True, nullable=False)
    cliente = db.Column(db.String(120), nullable=True)
    status = db.Column(db.String(20), nullable=False, default="Aberta")  # Aberta, Encerrada, Paga
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    itens = db.relationship("ComandaItem", back_populates="comanda", cascade="all, delete-orphan")

    @property
    def total(self):
        return sum(item.subtotal for item in self.itens)

class ItemCardapio(db.Model):
    __tablename__ = "cardapio"
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(200), nullable=False)
    categoria = db.Column(db.String(100), nullable=True)
    preco = db.Column(db.Numeric(10,2), nullable=False)

    def __repr__(self):
        return f"<ItemCardapio {self.nome}>"

class ComandaItem(db.Model):
    __tablename__ = "comanda_itens"
    id = db.Column(db.Integer, primary_key=True)
    comanda_id = db.Column(db.Integer, db.ForeignKey("comandas.id"), nullable=False)
    item_id = db.Column(db.Integer, db.ForeignKey("cardapio.id"), nullable=False)
    quantidade = db.Column(db.Integer, nullable=False, default=1)
    preco_unitario = db.Column(db.Numeric(10,2), nullable=False)

    comanda = db.relationship("Comanda", back_populates="itens")
    item = db.relationship("ItemCardapio")

    @property
    def subtotal(self):
        return float(self.quantidade) * float(self.preco_unitario)
