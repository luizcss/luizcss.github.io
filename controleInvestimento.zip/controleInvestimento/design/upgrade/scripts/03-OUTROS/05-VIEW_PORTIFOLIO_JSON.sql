CREATE VIEW IF NOT EXISTS VW_PORTIFOLIO_JSON
AS SELECT json_object('portifolio',   
json_group_array ( 
    json_object('codigoAtivo', ATV.CODIGO,
                'descricaoAtivo',ATV.DESCRICAO,
                'categoria',CAT.DESCRICAO,
                'quantidade',PORTI.QUANTIDADE,
                'precoMedio',PORTI.PRECO_MEDIO,
                'corretora',COR.DESCRICAO,
                'cnpjAtivo',ATV.CNPJ,
                'precoMercadoAtual',PORTI.PRECO_MERCADO,
                'codigoCorretora',COR.CODIGO)
                )
    ) resultado
FROM PORTIFOLIO PORTI
INNER JOIN CORRETORA COR ON PORTI.CODIGO_CORRETORA = COR.CODIGO
INNER JOIN ATIVO ATV ON PORTI.CODIGO_ATIVO = ATV.CODIGO
INNER JOIN CATEGORIA CAT ON ATV.CODIGO_CATEGORIA = CAT.CODIGO