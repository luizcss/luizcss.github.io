CREATE VIEW IF NOT EXISTS VW_ATIVO_JSON
AS SELECT json_object('ativo',   
json_group_array ( 
    json_object('id', ATV.ID, 
                'codigo', ATV.CODIGO,
                'descricao',ATV.DESCRICAO,
                'codigoCategoria',ATV.CODIGO_CATEGORIA,
                'cnpj',ATV.CNPJ,
                'dataCriacao', ATV.DATA_CRIACAO)
    )) resultado
from ATIVO ATV;


-- https://www.sqlitetutorial.net/sqlite-json-functions/sqlite-json_group_array-function/
-- https://www.sqlitetutorial.net/sqlite-json-functions/sqlite-json_group_object-function/
-- https://www.sqlitetutorial.net/sqlite-json-functions/
-- https://www.sqlitetutorial.net/sqlite-json-functions/sqlite-json_array-function/