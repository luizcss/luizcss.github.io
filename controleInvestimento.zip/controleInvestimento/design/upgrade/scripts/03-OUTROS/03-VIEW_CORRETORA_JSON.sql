CREATE VIEW IF NOT EXISTS VW_CORRETORA_JSON
AS SELECT json_object(
    'corretora',   json_group_array (
     json_object(
        'codigo',COR.CODIGO, 
        'descricao',COR.DESCRICAO,
        'cnpj',COR.CNPJ,
        'dataCriacao', COR.DATA_CRIACAO))) resultado
from CORRETORA COR;