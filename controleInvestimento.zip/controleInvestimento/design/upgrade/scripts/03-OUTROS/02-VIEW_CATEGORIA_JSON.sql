
CREATE VIEW IF NOT EXISTS VW_CATEGORIA_JSON
AS SELECT json_object('categoria',
json_group_array ( 
    json_object(
        'codigo',CAT.CODIGO,
        'descricao', CAT.descricao,
        'dataCriacao', CAT.DATA_CRIACAO)
        )) resultado
from CATEGORIA CAT;