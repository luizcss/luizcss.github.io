from util import MetodosUteis as metodosUteis
from flask_bootstrap import Bootstrap5
from controleInvestimento.controller import PortifolioController_fastapi as portifolioController
from fastapi import APIRouter, FastAPI
from fastapi.responses import HTMLResponse 
from starlette.templating import Jinja2Templates

import uvicorn

app = FastAPI()
routes = APIRouter()



if __name__ == '__main__':
    portifolioController.registrarApi(routes)
    app.include_router(routes)
    uvicorn.run(app, port=9000,         reload  = True    )