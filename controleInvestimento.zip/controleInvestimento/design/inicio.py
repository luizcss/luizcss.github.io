import pandas as pd
import yfinance as yf

data = pd.read_excel(r"C:\Estudo\python\controleInvestimento\PORTIFOLIO_AÇÕES.xlsx", sheet_name="Ativos")





def getValue(data, columnName):
    df = pd.DataFrame(data)
    # return df[['Corretora', 'Ativo']]
    return df[df.columns[1:4]]





tickers = ['ABEV3.SA', 'PETR4.SA', 'BCFF11.SA', 'AMZN']
for ticker in tickers:
    ticker_yahoo = yf.Ticker(ticker)
    data = ticker_yahoo.history()
    last_quote = data['Close'].iloc[-1]
    print(ticker, last_quote)