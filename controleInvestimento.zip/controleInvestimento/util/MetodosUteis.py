from collections import namedtuple
import json
from flask import Flask
from datetime import timedelta as timedelta
import repository.Conexao as conexao
from controller import AtivoController as ativoController, PortifolioController as portifolioController
import yfinance as yf

from service import PortifolioService as portifolioService
from service import AtivoService as ativoService

#https://medium.com/@hedgarbezerra35/api-rest-com-flask-autenticacao-25d99b8679b6
#//ADICIONAR autenticação

FORMATO_DATA_CONSULTA="%d/%m/%y %H:%M:%S"

def parseJsonObejct(jsonEntrada):
    jsonAux = json.dumps(jsonEntrada)
    object = json.loads(jsonAux, object_hook=customObejctDecoder)
    return object

def customObejctDecoder(estruturaDict):
    return namedtuple('X', estruturaDict.keys())(*estruturaDict.values())

def initComponentes(app: Flask):
    initRotas(app)
    conexao.start()

def initRotas(app: Flask):
    ativoController.registrarApi(app)
    portifolioController.registrarApi(app)    
 
def dataFormat(data):
    return data.strftime(FORMATO_DATA_CONSULTA)        

def obterValorMercado():
    lstAtivos = ativoService.obterAtivos()
    for ativo in lstAtivos:
        if(ativo.tipo == 'ACAO' or  ativo.tipo =='FII' or ativo.tipo == 'FIA' or  ativo.tipo =='BDR'):
            getCotacao(ativo.codigo+'.SA')
        elif(ativo.tipo == 'STOC' or ativo.tipo == 'REIT'):
            getCotacao(ativo.codigo)
      

def getCotacao(ativo):
    try:
        ticker_yahoo = yf.Ticker(ativo)
        data = ticker_yahoo.history()
        last_quote = data['Close'].iloc[-1]
        print(ativo, last_quote)
        valor  = float(last_quote)
        print(valor, last_quote)
        portifolioService.atualizarValoresMercado(ativo, valor)
    except Exception as e:
        print(f'Ocorreu um erro: {e} - {ativo}')
    

def formatFloat(fieldOri):
    return format(fieldOri, '.2f').replace('.',',')        