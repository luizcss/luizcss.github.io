from flask import Flask
from util import MetodosUteis as metodosUteis
from flask_bootstrap import Bootstrap5

app = Flask(__name__)
bootstrap = Bootstrap5(app)

if __name__ == '__main__':
    metodosUteis.initComponentes(app) 
    # metodosUteis.obterValorMercado()
    app.run(debug=True,port=9000)
