from repository import AtivoRepository as repository
from util import MetodosUteis as metodosUteis

def obterAtivos():
    return repository.getAll()

def obterAtivoPorId(id):
    return repository.getById(id)

def obterAtivoPorCodigo(codigo):
    return repository.getByCodigo(codigo)


def deleteAtivoPorId(id):
    repository.delete(id)
    return True

def criarAtivo(jsonAtivo):
    ativo = metodosUteis.parseJsonObejct(jsonAtivo)
    repository.save(ativo)
    return True


def atualizarAtivo(jsonAtivo, id):
    ativo = metodosUteis.parseJsonObejct(jsonAtivo)
    repository.update(ativo, id)
    return ativo