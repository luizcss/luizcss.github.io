from repository import PortofolioRepositorio as repository
from util import MetodosUteis as metodosUteis
from model.ResultadoPortifolio import ResultadoPortifolio

def obterPortifolioCompleto():
    lstAtivos =  repository.getAllComplete()
    for ativo in lstAtivos:
        patrimonioAtual = None
        valorCusto = ativo.precoMedio * ativo.quantidade
        valorAtual =  ativo.valorMercado * ativo.quantidade
        ativo.apoioImposto = montaApoioImposto(ativo.codigoAtivo, ativo.quantidade, ativo.nomeAtivo, ativo.cnpjAtivo, ativo.corretora, valorCusto)
        patrimonioAtual = calculoPatrimonioAtual(valorAtual, valorCusto)
        prejuizo =  float(patrimonioAtual) < 0 
        ativo.prejuizo = str(prejuizo)
        ativo.valorCusto = valorCusto #format(valorCusto, '.2f')
        ativo.valorAtual = valorAtual #format(valorAtual, '.2f')
        ativo.patrimonioAtual = patrimonioAtual #format(patrimonioAtual, '.2f')
    return lstAtivos

def obterPortifolioPorCorretora(corretora):
    lstAtivos =  repository.getAllPorCorreta(corretora)
    for ativo in lstAtivos:
        patrimonioAtual = None
        valorCusto = ativo.precoMedio * ativo.quantidade
        valorAtual =  ativo.valorMercado * ativo.quantidade
        ativo.apoioImposto = montaApoioImposto(ativo.codigoAtivo, ativo.quantidade, ativo.nomeAtivo, ativo.cnpjAtivo, ativo.corretora, valorCusto)
        patrimonioAtual = calculoPatrimonioAtual(valorAtual, valorCusto)
        prejuizo =  float(patrimonioAtual) < 0 
        ativo.prejuizo = str(prejuizo)
        ativo.valorCusto = valorCusto #format(valorCusto, '.2f')
        ativo.valorAtual = valorAtual #format(valorAtual, '.2f')
        ativo.patrimonioAtual = patrimonioAtual #format(patrimonioAtual, '.2f')
    return lstAtivos


def montaApoioImposto(codigoAtivo, quantidade, nome, cnpjAtivo, corretora, valorCusto):
    valorCustoStr = format(valorCusto, '.2f').replace('.',',')
    strApoioImposto = f"{quantidade} /{codigoAtivo} - {nome} / {cnpjAtivo} / {corretora} / {valorCustoStr}"
    print(strApoioImposto.strip())
    return strApoioImposto.strip()


def calculoPatrimonioAtual(valorAtual, valorCusto):
     return valorAtual-valorCusto

def atualizarValoresMercado(ativo, precoMercado):
    codigo = ativo.replace('.SA', '')
    repository.updateValorMercado(precoMercado, codigo)

def portifolioCompleto():
    lstAtivos = obterPortifolioCompleto()
    totalPatrimonio = 0.0
    totalAtual = 0.0
    totalCusto = 0.0

    for ativo in lstAtivos:
        # ativo.valorCusto = metodosUteis.formatFloat(ativo.valorCusto)
        # ativo.precoMedio = metodosUteis.formatFloat(ativo.precoMedio)
        # ativo.valorAtual = metodosUteis.formatFloat(ativo.valorAtual)
        # ativo.valorMercado = metodosUteis.formatFloat(ativo.valorMercado)
        # ativo.patrimonioAtual = metodosUteis.formatFloat(ativo.patrimonioAtual)
        if(ativo.tipoAtivo == 'STOCKS' or ativo.tipoAtivo == 'REITS'or ativo.tipoAtivo == 'TESOURO DIRETO'):
            totalPatrimonio=totalPatrimonio+0.0
            totalAtual=totalAtual+0.0
            totalCusto=totalCusto+0.0
        else:
            totalPatrimonio=totalPatrimonio+float(ativo.patrimonioAtual)
            totalAtual=totalPatrimonio+float(ativo.valorAtual)
            totalCusto=totalPatrimonio+float(ativo.valorCusto)

    prejuizo = totalPatrimonio < 0
    # totalPatrimonioStr = metodosUteis.formatFloat(totalPatrimonio)
    # totalAtualStr = metodosUteis.formatFloat(totalAtual)
    # totalCustoStr= metodosUteis.formatFloat(totalCusto)
    return ResultadoPortifolio(lstAtivos, totalPatrimonio, totalAtual, totalCusto ,prejuizo)