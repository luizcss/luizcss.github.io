from repository import TipoAtivoRepository as repository
from util import MetodosUteis as metodosUteis

def obterTipoAtivo():
    return repository.getAll() 