class PortifolioCompleto():
    def __init__(self,codigoAtivo, nomeAtivo, tipoAtivo, quantidade, valorMercado, precoMedio, valorCusto, valorAtual, patrimonioAtual, corretora, cnpjAtivo, apoioImposto, prejuizo):
        self.id = id
        self.codigoAtivo = codigoAtivo
        self.nomeAtivo = nomeAtivo
        self.tipoAtivo = tipoAtivo
        self.quantidade = quantidade
        self.valorMercado = valorMercado
        self.precoMedio = precoMedio
        self.valorCusto = valorCusto
        self.valorAtual = valorAtual
        self.patrimonioAtual = patrimonioAtual
        self.corretora = corretora
        self.cnpjAtivo = cnpjAtivo
        self.apoioImposto = apoioImposto
        self.prejuizo = prejuizo
    
    
    