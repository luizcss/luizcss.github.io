class ResultadoPortifolio():
    def __init__(self,prejuizo, totalPatrimonio, totalAtual,totalCusto, lstPortifolio):
        prejuizo = prejuizo
        totalPatrimonio = totalPatrimonio
        totalAtual = totalAtual
        totalCusto= totalCusto
        lstPortifolio = lstPortifolio
    
    