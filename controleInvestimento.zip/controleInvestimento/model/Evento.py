class Evento():
    def __init__(self,data , evento):
        self.data = data
        self.evento = evento