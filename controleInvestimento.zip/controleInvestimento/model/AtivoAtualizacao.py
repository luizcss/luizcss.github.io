class AtivoAtualizacao():
    def __init__(self,codigo , precoMercado):
        self.codigo = codigo
        self.precoMercado = precoMercado