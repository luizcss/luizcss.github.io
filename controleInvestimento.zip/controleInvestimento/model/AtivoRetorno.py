class AtivoRetorno():
    def __init__(self,codigo , nome, tipo, quantidade,valorMercado, precoMedio, valorCusto, valorAtual, patrimonioAtual, corretora, cnpj, apoioImposto, prejuizo):
        self.codigo = codigo
        self.nome = nome
        self.tipo = tipo
        self.quantidade = quantidade
        self.valorMercado = valorMercado
        self.precoMedio = precoMedio
        self.valorCusto = valorCusto
        self.valorAtual = valorAtual
        self.patrimonioAtual = patrimonioAtual
        self.corretora = corretora
        self.cnpj = cnpj
        self.apoioImposto = apoioImposto
        self.prejuizo = prejuizo