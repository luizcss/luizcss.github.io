from flask import Flask, request, render_template,redirect, jsonify
from service import PortifolioService as portifolioService
from util import MetodosUteis as metodosUteis
import json
from fastapi import APIRouter, FastAPI
import uvicorn
from fastapi.encoders import jsonable_encoder
from starlette.templating import Jinja2Templates
from fastapi.responses import HTMLResponse 




templates = Jinja2Templates(directory="templates")

def portifolios():
    lstAtivos = [] 
    lstAtivos = portifolioService.obterPortifolioCompleto()
    totalPatrimonio = 0.0
    totalAtual = 0.0
    totalCusto = 0.0

    for ativo in lstAtivos:
        if(ativo.tipoAtivo == 'STOCKS' or ativo.tipoAtivo == 'REITS'or ativo.tipoAtivo == 'TESOURO DIRETO'):
            totalPatrimonio=totalPatrimonio+0.0
            totalAtual=totalAtual+0.0
            totalCusto=totalCusto+0.0
        else:
            totalPatrimonio=totalPatrimonio+float(ativo.patrimonioAtual)
            totalAtual=totalPatrimonio+float(ativo.valorAtual)
            totalCusto=totalPatrimonio+float(ativo.valorCusto)

    prejuizo = totalPatrimonio < 0
    totalPatrimonioStr = metodosUteis.formatFloat(totalPatrimonio)
    totalAtualStr = metodosUteis.formatFloat(totalAtual)
    totalCustoStr= metodosUteis.formatFloat(totalCusto)

    for ativo in lstAtivos:
        ativo.valorCusto = metodosUteis.formatFloat(ativo.valorCusto)
        ativo.precoMedio = metodosUteis.formatFloat(ativo.precoMedio)
        ativo.valorAtual = metodosUteis.formatFloat(ativo.valorAtual)
        ativo.valorMercado = metodosUteis.formatFloat(ativo.valorMercado)
        ativo.patrimonioAtual = metodosUteis.formatFloat(ativo.patrimonioAtual)


    return templates.TemplateResponse("portifolio.html",context={
                           "lstAtivos":lstAtivos,"totalPatrimonio":totalPatrimonioStr, 
                             "totalAtual":totalAtualStr, "totalCusto":totalCustoStr, 
                             "prejuizo":prejuizo, 
                              "totalAtivos" : len(lstAtivos) })


def portifoliosNew():
    lstAtivos = [] 
    lstAtivos = portifolioService.obterPortifolioCompleto()
    totalPatrimonio = 0.0
    totalAtual = 0.0
    totalCusto = 0.0

    for ativo in lstAtivos:
        if(ativo.tipoAtivo == 'STOCKS' or ativo.tipoAtivo == 'REITS'or ativo.tipoAtivo == 'TESOURO DIRETO'):
            totalPatrimonio=totalPatrimonio+0.0
            totalAtual=totalAtual+0.0
            totalCusto=totalCusto+0.0
        else:
            totalPatrimonio=totalPatrimonio+float(ativo.patrimonioAtual)
            totalAtual=totalPatrimonio+float(ativo.valorAtual)
            totalCusto=totalPatrimonio+float(ativo.valorCusto)

    prejuizo = totalPatrimonio < 0
    totalPatrimonioStr = metodosUteis.formatFloat(totalPatrimonio)
    totalAtualStr = metodosUteis.formatFloat(totalAtual)
    totalCustoStr= metodosUteis.formatFloat(totalCusto)

    for ativo in lstAtivos:
        ativo.valorCusto = metodosUteis.formatFloat(ativo.valorCusto)
        ativo.precoMedio = metodosUteis.formatFloat(ativo.precoMedio)
        ativo.valorAtual = metodosUteis.formatFloat(ativo.valorAtual)
        ativo.valorMercado = metodosUteis.formatFloat(ativo.valorMercado)
        ativo.patrimonioAtual = metodosUteis.formatFloat(ativo.patrimonioAtual)

    return render_template("portifolioNew.html", 
                           lstAtivos=lstAtivos,totalPatrimonio =totalPatrimonioStr, 
                             totalAtual=totalAtualStr, totalCusto=totalCustoStr, 
                             prejuizo=prejuizo, 
                              totalAtivos = len(lstAtivos) )

def portifoliosPorCorretora(corretora):
    lstAtivos = [] 
    lstAtivos = portifolioService.obterPortifolioPorCorretora(corretora)
    totalPatrimonio = 0.0
    totalAtual = 0.0
    totalCusto = 0.0

    for ativo in lstAtivos:
        if(ativo.tipoAtivo == 'STOCKS' or ativo.tipoAtivo == 'REITS'or ativo.tipoAtivo == 'TESOURO DIRETO'):
            totalPatrimonio=totalPatrimonio+0.0
            totalAtual=totalAtual+0.0
            totalCusto=totalCusto+0.0
        else:
            totalPatrimonio=totalPatrimonio+float(ativo.patrimonioAtual)
            totalAtual=totalPatrimonio+float(ativo.valorAtual)
            totalCusto=totalPatrimonio+float(ativo.valorCusto)

    prejuizo = totalPatrimonio < 0
    totalPatrimonioStr = metodosUteis.formatFloat(totalPatrimonio)
    totalAtualStr = metodosUteis.formatFloat(totalAtual)
    totalCustoStr= metodosUteis.formatFloat(totalCusto)

    for ativo in lstAtivos:
        ativo.valorCusto = metodosUteis.formatFloat(ativo.valorCusto)
        ativo.precoMedio = metodosUteis.formatFloat(ativo.precoMedio)
        ativo.valorAtual = metodosUteis.formatFloat(ativo.valorAtual)
        ativo.valorMercado = metodosUteis.formatFloat(ativo.valorMercado)
        ativo.patrimonioAtual = metodosUteis.formatFloat(ativo.patrimonioAtual)

    return render_template("portifolio.html", 
                           lstAtivos=lstAtivos,totalPatrimonio =totalPatrimonioStr, 
                             totalAtual=totalAtualStr, totalCusto=totalCustoStr, 
                             prejuizo=prejuizo, 
                              totalAtivos = len(lstAtivos) )

def portifolioCompleto():
    result = portifolioService.portifolioCompleto()
    return  jsonable_encoder(result)

def formartAtivos(lstAtivos):
    for ativo in lstAtivos:
        ativo.valorCusto = metodosUteis.formatFloat(ativo.valorCusto)
        ativo.precoMedio = metodosUteis.formatFloat(ativo.precoMedio)
        ativo.valorAtual = metodosUteis.formatFloat(ativo.valorAtual)
        ativo.valorMercado = metodosUteis.formatFloat(ativo.valorMercado)
        ativo.patrimonioAtual = metodosUteis.formatFloat(ativo.patrimonioAtual)
    return lstAtivos

def registrarApi(routes: APIRouter): 
    routes.add_api_route("/portifolios",  endpoint= portifolios, methods=["GET"])
    routes.add_api_route("/portifoliosNew",endpoint= portifoliosNew, methods=["GET"])
    routes.add_api_route("/portifolios/<corretora>", endpoint=portifoliosPorCorretora, methods=["GET"])
    routes.add_api_route("/portifolioCompleto", endpoint=portifolioCompleto, methods=["GET"])
    