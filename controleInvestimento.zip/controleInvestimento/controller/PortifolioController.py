from flask import Flask, request, render_template,redirect, jsonify
from service import PortifolioService as portifolioService
from util import MetodosUteis as metodosUteis
import json
from model.Evento import Evento

def portifolios():
    lstAtivos = [] 
    lstEventos = [] 
    lstAtivos = portifolioService.obterPortifolioCompleto()
    totalPatrimonio = 0.0
    totalAtual = 0.0
    totalCusto = 0.0

    for ativo in lstAtivos:
        if(ativo.tipoAtivo == 'STOCKS' or ativo.tipoAtivo == 'REITS'or ativo.tipoAtivo == 'TESOURO DIRETO'):
            totalPatrimonio=totalPatrimonio+0.0
            totalAtual=totalAtual+0.0
            totalCusto=totalCusto+0.0
        else:
            totalPatrimonio=totalPatrimonio+float(ativo.patrimonioAtual)
            totalAtual=totalPatrimonio+float(ativo.valorAtual)
            totalCusto=totalPatrimonio+float(ativo.valorCusto)

    prejuizo = totalPatrimonio < 0
    totalPatrimonioStr = metodosUteis.formatFloat(totalPatrimonio)
    totalAtualStr = metodosUteis.formatFloat(totalAtual)
    totalCustoStr= metodosUteis.formatFloat(totalCusto)

    for ativo in lstAtivos:
        ativo.valorCusto = metodosUteis.formatFloat(ativo.valorCusto)
        ativo.precoMedio = metodosUteis.formatFloat(ativo.precoMedio)
        ativo.valorAtual = metodosUteis.formatFloat(ativo.valorAtual)
        ativo.valorMercado = metodosUteis.formatFloat(ativo.valorMercado)
        ativo.patrimonioAtual = metodosUteis.formatFloat(ativo.patrimonioAtual)

    lstEventos.append(Evento("2024-09-20", "Aquisição"))
    lstEventos.append(Evento("2024-09-25", "Dividendo"))
    return render_template("portifolio.html", 
                           lstAtivos=lstAtivos,totalPatrimonio =totalPatrimonioStr, 
                             totalAtual=totalAtualStr, totalCusto=totalCustoStr, 
                             prejuizo=prejuizo, 
                              totalAtivos = len(lstAtivos),
                               lstEventos = lstEventos )


def portifoliosNew():
    lstAtivos = [] 
    lstAtivos = portifolioService.obterPortifolioCompleto()
    totalPatrimonio = 0.0
    totalAtual = 0.0
    totalCusto = 0.0

    for ativo in lstAtivos:
        if(ativo.tipoAtivo == 'STOCKS' or ativo.tipoAtivo == 'REITS'or ativo.tipoAtivo == 'TESOURO DIRETO'):
            totalPatrimonio=totalPatrimonio+0.0
            totalAtual=totalAtual+0.0
            totalCusto=totalCusto+0.0
        else:
            totalPatrimonio=totalPatrimonio+float(ativo.patrimonioAtual)
            totalAtual=totalPatrimonio+float(ativo.valorAtual)
            totalCusto=totalPatrimonio+float(ativo.valorCusto)

    prejuizo = totalPatrimonio < 0
    totalPatrimonioStr = metodosUteis.formatFloat(totalPatrimonio)
    totalAtualStr = metodosUteis.formatFloat(totalAtual)
    totalCustoStr= metodosUteis.formatFloat(totalCusto)

    for ativo in lstAtivos:
        ativo.valorCusto = metodosUteis.formatFloat(ativo.valorCusto)
        ativo.precoMedio = metodosUteis.formatFloat(ativo.precoMedio)
        ativo.valorAtual = metodosUteis.formatFloat(ativo.valorAtual)
        ativo.valorMercado = metodosUteis.formatFloat(ativo.valorMercado)
        ativo.patrimonioAtual = metodosUteis.formatFloat(ativo.patrimonioAtual)

    return render_template("portifolioNew.html", 
                           lstAtivos=lstAtivos,totalPatrimonio =totalPatrimonioStr, 
                             totalAtual=totalAtualStr, totalCusto=totalCustoStr, 
                             prejuizo=prejuizo, 
                              totalAtivos = len(lstAtivos) )

def portifoliosPorCorretora(corretora):
    lstAtivos = [] 
    lstAtivos = portifolioService.obterPortifolioPorCorretora(corretora)
    totalPatrimonio = 0.0
    totalAtual = 0.0
    totalCusto = 0.0

    for ativo in lstAtivos:
        if(ativo.tipoAtivo == 'STOCKS' or ativo.tipoAtivo == 'REITS'or ativo.tipoAtivo == 'TESOURO DIRETO'):
            totalPatrimonio=totalPatrimonio+0.0
            totalAtual=totalAtual+0.0
            totalCusto=totalCusto+0.0
        else:
            totalPatrimonio=totalPatrimonio+float(ativo.patrimonioAtual)
            totalAtual=totalPatrimonio+float(ativo.valorAtual)
            totalCusto=totalPatrimonio+float(ativo.valorCusto)

    prejuizo = totalPatrimonio < 0
    totalPatrimonioStr = metodosUteis.formatFloat(totalPatrimonio)
    totalAtualStr = metodosUteis.formatFloat(totalAtual)
    totalCustoStr= metodosUteis.formatFloat(totalCusto)

    for ativo in lstAtivos:
        ativo.valorCusto = metodosUteis.formatFloat(ativo.valorCusto)
        ativo.precoMedio = metodosUteis.formatFloat(ativo.precoMedio)
        ativo.valorAtual = metodosUteis.formatFloat(ativo.valorAtual)
        ativo.valorMercado = metodosUteis.formatFloat(ativo.valorMercado)
        ativo.patrimonioAtual = metodosUteis.formatFloat(ativo.patrimonioAtual)

    return render_template("portifolio.html", 
                           lstAtivos=lstAtivos,totalPatrimonio =totalPatrimonioStr, 
                             totalAtual=totalAtualStr, totalCusto=totalCustoStr, 
                             prejuizo=prejuizo, 
                              totalAtivos = len(lstAtivos) )

def portifolioCompleto():
    result = portifolioService.portifolioCompleto()
    # return json.dumps(result, default=lambda x: x.dir)
    return jsonify(result, default=lambda x: x.dir)

def formartAtivos(lstAtivos):
    for ativo in lstAtivos:
        ativo.valorCusto = metodosUteis.formatFloat(ativo.valorCusto)
        ativo.precoMedio = metodosUteis.formatFloat(ativo.precoMedio)
        ativo.valorAtual = metodosUteis.formatFloat(ativo.valorAtual)
        ativo.valorMercado = metodosUteis.formatFloat(ativo.valorMercado)
        ativo.patrimonioAtual = metodosUteis.formatFloat(ativo.patrimonioAtual)
    return lstAtivos

def registrarApi(app: Flask): 
    app.add_url_rule("/portifolioCompleto", "portifolioCompleto", portifolioCompleto, methods=["GET"])
    app.add_url_rule("/portifolios", "portifolios", portifolios, methods=["GET"])
    app.add_url_rule("/portifoliosNew", "portifoliosNew", portifoliosNew, methods=["GET"])
    app.add_url_rule("/portifolios/<corretora>", "portifoliosPorCorretora", portifoliosPorCorretora, methods=["GET"])
    