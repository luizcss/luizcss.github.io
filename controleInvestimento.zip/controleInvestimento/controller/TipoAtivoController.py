from flask import Flask, request, json, render_template,redirect
from service import TipoAtivoService as tipoAtivoService

def obterTipoAtivo():
    ativos = tipoAtivoService.obterTipoAtivo()
    return json.dumps(ativos, default=lambda x: x.__dict__)

def registrarApi(app: Flask): 
    app.add_url_rule("/tipoAtivo", "obterTipoAtivo", obterTipoAtivo, methods=["GET"])