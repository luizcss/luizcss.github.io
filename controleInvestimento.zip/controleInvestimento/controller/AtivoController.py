from flask import Flask, request, json, render_template,redirect
from service import AtivoService as ativoService
from service import TipoAtivoService as tipoAtivoService


def criarAtivo():
    req_data = request.get_data()
    print(req_data)
    # ativoService.criarAtivo(req_data)
    return True

def ativos():
    lstAtivos = ativoService.obterAtivos()
    lstTiposAtivo = tipoAtivoService.obterTipoAtivo()
    return render_template("ativo_v2.html", lstAtivos=lstAtivos,lstTiposAtivo=lstTiposAtivo, sizeList = len(lstAtivos))

def obterAtivos():
    ativos = ativoService.obterAtivos()
    return json.dumps(ativos, default=lambda x: x.__dict__)

def obterAtivoPorId(id):
    ativo = ativoService.obterAtivoPorId(id)
    return json.dumps(ativo, default=lambda x: x.__dict__)

def obterAtivoPorCodigo(codigo):
    ativo = ativoService.obterAtivoPorCodigo(codigo)
    return json.dumps(ativo, default=lambda x: x.__dict__)


def delete(id):
    ativo = ativoService.deleteAtivoPorId(id)
    return json.dumps(ativo, default=lambda x: x.__dict__)

def atualizar(id):
    req_data = request.get_json()
    ativo = ativoService.updateAtivo(req_data, id)
    return json.dumps(ativo, default=lambda x: x.__dict__)

def registrarApi(app: Flask): 
    app.add_url_rule("/ativos", "ativos", ativos, methods=["GET"])
    app.add_url_rule("/ativo", "obterAtivos", obterAtivos, methods=["GET"])
    app.add_url_rule("/ativos", "criarAtivo", criarAtivo, methods=["POST"])
    app.add_url_rule("/ativo/<id>","obterAtivoPorId", obterAtivoPorId, methods=["GET"])
    app.add_url_rule("/ativo/<id>", "atualizarAtivo", atualizar, methods=["PUT"])
    app.add_url_rule("/ativo/<id>", "deleteAtivo", delete, methods=["DELETE"])