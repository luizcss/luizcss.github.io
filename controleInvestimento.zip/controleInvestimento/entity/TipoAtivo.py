class TipoAtivo():
    def __init__(self, codigo , nome, dataAtualizacao):
        self.codigo = codigo
        self.nome = nome
        self.dataAtualizacao = dataAtualizacao