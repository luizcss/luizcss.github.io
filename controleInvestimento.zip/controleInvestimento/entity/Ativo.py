class Ativo():
    def __init__(self,id, codigo , nome, tipo, cnpj, dataAtualizacao):
        self.id = id
        self.codigo = codigo
        self.nome = nome
        self.tipo = tipo
        self.cnpj = cnpj
        self.dataAtualizacao = dataAtualizacao