class Portifolio():
    def __init__(self,id, codigoAtivo , quantidade, precoMedio, codigoCorretora, dataAtualizacao):
        self.id = id
        self.codigoAtivo = codigoAtivo
        self.quantidade = quantidade
        self.precoMedio = precoMedio
        self.codigoCorretora = codigoCorretora
        self.dataAtualizacao = dataAtualizacao