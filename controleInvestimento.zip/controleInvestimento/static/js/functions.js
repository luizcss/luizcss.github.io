function copy(codigo) {
    label = document.getElementById('inputApoioImposto_' + codigo);
    text = (label.innerText || label.textContent);
    navigator.clipboard.writeText(text);
}