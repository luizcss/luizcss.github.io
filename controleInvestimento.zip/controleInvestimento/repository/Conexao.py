import sqlite3
import os

#https://pythonclub.com.br/gerenciando-banco-dados-sqlite3-python-parte1.html
def criarTabelas(nomeScript):
    conn = abrirConexao()
    cursor = conn.cursor()
    caminho_relativo = '..\\scripts\\01-ESTRUTURA\\'+nomeScript
    caminho_absoluto = os.path.join(os.path.dirname(__file__), caminho_relativo)
    try:
        with open(caminho_absoluto, 'r',encoding="utf8") as arquivo:
            conteudo = arquivo.read()
            cursor.execute(conteudo)
    except FileNotFoundError:
        print(f'O arquivo {caminho_absoluto} não foi encontrado.')
    except Exception as e:
        print(f'Ocorreu um erro: {e}')
    finally:
        print(f'Script executado {nomeScript}.')
    cursor.close()
    fecharConexao(conn)

def abrirConexao():
    conn = sqlite3.connect('INVESTIMENTO.db')
    return conn

def fecharConexao(conn):
    if conn:
        conn.close()
        print("Conexão fechada.") 

def cargaInicial(nomeScript):
    conn = abrirConexao()
    cursor = conn.cursor()
    caminho_relativo = '..\\scripts\\02-CARGA\\'+nomeScript
    caminho_absoluto = os.path.join(os.path.dirname(__file__), caminho_relativo)
    try:
        with open(caminho_absoluto, 'r',encoding="utf8") as arquivo:
            conteudo = arquivo.read()
            cursor.executescript(conteudo)
    except FileNotFoundError:
        print(f'O arquivo {caminho_absoluto} não foi encontrado.')
    except Exception as e:
        print(f'Ocorreu um erro: {e}')
    finally:
        print(f'Script executado {nomeScript}.')
    cursor.close()
    fecharConexao(conn) 

def view(nomeScript):
    conn = abrirConexao()
    cursor = conn.cursor()
    caminho_relativo = '..\\scripts\\03-OUTROS\\'+nomeScript
    caminho_absoluto = os.path.join(os.path.dirname(__file__), caminho_relativo)
    try:
        with open(caminho_absoluto, 'r',encoding="utf8") as arquivo:
            conteudo = arquivo.read()
            cursor.executescript(conteudo)
    except FileNotFoundError:
        print(f'O arquivo {caminho_absoluto} não foi encontrado.')
    except Exception as e:
        print(f'Ocorreu um erro: {e}')
    finally:
        print(f'Script executado {nomeScript}.')
    cursor.close()
    fecharConexao(conn)     

def start():
    for filename in os.listdir("./scripts/01-ESTRUTURA"):
       print(filename)
       criarTabelas(filename)
    for filename in os.listdir("./scripts/02-CARGA"):
       print(filename)
       cargaInicial(filename)  
    for filename in os.listdir("./scripts/03-OUTROS"):
       print(filename)
       view(filename)        