from repository import Conexao as conexao
import sqlite3
from entity.Ativo import Ativo

SCRIPT_INSERT = "INSERT INTO ATIVO (CODIGO, DESCRICAO,CODIGO_CATEGORIA, CNPJ,DATA_CRIACAO ) VALUES(?, ?, ?, ?);"
SCRIPT_UPDATE = "UPDATE ATIVO SET CODIGO=?, DESCRICAO=?, CODIGO_CATEGORIA=?, CNPJ=?, DATA_CRIACAO=? WHERE ID = filtro;"
SCRIPT_DELETE = "DELETE FROM CAMPEONATO WHERE ID = filtro;"
SCRIPT_SELECT_ALL = "SELECT ID, CODIGO, DESCRICAO, CODIGO_CATEGORIA, CNPJ, DATA_CRIACAO FROM ATIVO"
SCRIPT_SELECT_BY_ID = "SELECT ID, CODIGO, DESCRICAO, CODIGO_CATEGORIA, CNPJ, DATA_CRIACAO FROM ATIVO WHERE ID = filtro;"
SCRIPT_SELECT_BY_CODIGO = "SELECT ID, CODIGO, DESCRICAO, CODIGO_CATEGORIA, CNPJ, DATA_CRIACAO FROM ATIVO WHERE CODIGO = filtro;"


def save(ativo: Ativo):
    try:
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        cursor.execute(SCRIPT_INSERT, ativo)
        conn.commit()
    except sqlite3.Error as error:
        print("Falha ao criar o ativo.", error)
    finally:
        cursor.close()
        conexao.fecharConexao(conn)

def update(ativo: Ativo, id: int):
    try:
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        script = SCRIPT_UPDATE.replace("filtro", id)
        cursor.execute(script, ativo)
        conn.commit()
        cursor.close()
        print(f'Registro id {id} atualizado com sucesso')
    except sqlite3.Error as error:
        print(f'Falha ao atualizar o ativo {id}.', error)
    finally:
        conexao.fecharConexao(conn) 

def delete(id):
    try:
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        script = SCRIPT_DELETE.replace("filtro", id)
        cursor.execute(script)
        conn.commit()
        cursor.close()
        print(f'Registro id {id} deletado com sucesso')
    except sqlite3.Error as error:
        print(f'Falha ao deletar o campeonato {id}.', error)
    finally:
        conexao.fecharConexao(conn)      

def getById(id):
    try:
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        script = SCRIPT_SELECT_BY_ID.replace("filtro", id)
        cursor.execute(script)
        ativo = None
        for linha in cursor.fetchall():
            ativo = Ativo(linha[0], linha[1], linha[2], linha[3], None)
    except sqlite3.Error as error:
        print(f'Falha na consulta do ativo {id}', error)
    finally:
        conexao.fecharConexao(conn)
    return ativo

def getByCodigo(codigo):
    try:
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        script = SCRIPT_SELECT_BY_CODIGO.replace("filtro", codigo)
        cursor.execute(script)
        ativo = None
        for linha in cursor.fetchall():
            ativo = Ativo(linha[0], linha[1], linha[2], linha[3], linha[4],linha[5])
    except sqlite3.Error as error:
        print(f'Falha na consulta do ativo {codigo}', error)
    finally:
        conexao.fecharConexao(conn)
    return ativo


def getAll():
    try:
        ativos = []
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        cursor.execute(SCRIPT_SELECT_ALL)
        for linha in cursor.fetchall():
            ativos.append(Ativo(linha[0], linha[1], linha[2], linha[3], linha[4],linha[5]))
        cursor.close()
    except sqlite3.Error as error:
        print("Falha na consulta dos ativos", error)
    finally:
        conexao.fecharConexao(conn)
    return ativos                 