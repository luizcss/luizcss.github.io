
from repository import Conexao as conexao
import sqlite3
from entity.Portifolio import Portifolio
from model.PortifolioCompleto import PortifolioCompleto

SCRIPT_INSERT = "INSERT INTO ATIVO (CODIGO, DESCRICAO,TIPO, CNPJ,DATA_CRIACAO ) VALUES(?, ?, ?, ?);"
SCRIPT_UPDATE = "UPDATE PORTOFOLIO SET PRECO_MERCADO = ?  WHERE CODIGO_ATIVO = 'filtro';"
SCRIPT_UPDATE_VALOR_MERCADO = "UPDATE PORTIFOLIO SET PRECO_MERCADO = valorMercado WHERE CODIGO_ATIVO = 'filtro';" 
SCRIPT_DELETE = "DELETE FROM CAMPEONATO WHERE ID = filtro;"
SCRIPT_SELECT_ALL = "SELECT ID, CODIGO, DESCRICAO, TIPO, CNPJ, DATA_CRIACAO FROM ATIVO"
SCRIPT_SELECT_BY_ID = "SELECT ID, CODIGO, DESCRICAO, TIPO, CNPJ, DATA_CRIACAO FROM ATIVO WHERE ID = filtro;"
SCRIPT_SELECT_BY_CODIGO = "SELECT ID, CODIGO, DESCRICAO, TIPO, CNPJ, DATA_CRIACAO FROM ATIVO WHERE CODIGO = filtro;"
SCRIPT_CONSULTA_COMPLETA ="SELECT CODIGO_ATIVO, DESCRICAO_ATIVO, CATEGORIA , QUANTIDADE, PRECO_MEDIO, CNPJ_ATIVO, CORRETORA_DESCRICAO, PRECO_MERCADO_ATUAL FROM vw_consulta_portifolio;"
SCRIPT_CONSULTA_POR_CORRETORA ="SELECT CODIGO_ATIVO, DESCRICAO_ATIVO, CATEGORIA , QUANTIDADE, PRECO_MEDIO, CNPJ_ATIVO, CORRETORA_DESCRICAO, PRECO_MERCADO_ATUAL FROM vw_consulta_portifolio WHERE CODIGO_CORRETORA = UPPER('filtro')"


def save(portifolio: Portifolio):
    try:
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        cursor.execute(SCRIPT_INSERT, portifolio)
        conn.commit()
    except sqlite3.Error as error:
        print("Falha ao criar o portifolio.", error)
    finally:

        cursor.close()
        conexao.fecharConexao(conn)

def update(Portifolio: Portifolio, id: int):
    try:
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        script = SCRIPT_UPDATE.replace("filtro", id)
        cursor.execute(script, Portifolio)
        conn.commit()
        cursor.close()
        print(f'Registro id {id} atualizado com sucesso')
    except sqlite3.Error as error:
        print(f'Falha ao atualizar o Portifolio {id}.', error)
    finally:
        conexao.fecharConexao(conn) 

def delete(id):
    try:
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        script = SCRIPT_DELETE.replace("filtro", id)
        cursor.execute(script)
        conn.commit()
        cursor.close()
        print(f'Registro id {id} deletado com sucesso')
    except sqlite3.Error as error:
        print(f'Falha ao deletar o campeonato {id}.', error)
    finally:
        conexao.fecharConexao(conn)      

def getById(id):
    try:
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        script = SCRIPT_SELECT_BY_ID.replace("filtro", id)
        cursor.execute(script)
        ativo = None
        for linha in cursor.fetchall():
            ativo = Portifolio(linha[0], linha[1], linha[2], linha[3], None)
    except sqlite3.Error as error:
        print(f'Falha na consulta do ativo {id}', error)
    finally:
        conexao.fecharConexao(conn)
    return ativo

def getByCodigo(codigo):
    try:
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        script = SCRIPT_SELECT_BY_CODIGO.replace("filtro", codigo)
        cursor.execute(script)
        ativo = None
        for linha in cursor.fetchall():
            ativo = Portifolio(linha[0], linha[1], linha[2], linha[3], linha[4],linha[5])
    except sqlite3.Error as error:
        print(f'Falha na consulta do ativo {codigo}', error)
    finally:
        conexao.fecharConexao(conn)
    return ativo

def getAll():
    try:
        ativos = []
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        cursor.execute(SCRIPT_SELECT_ALL)
        for linha in cursor.fetchall():
            ativos.append(Portifolio(linha[0], linha[1], linha[2], linha[3], linha[4],linha[5]))
        cursor.close()
    except sqlite3.Error as error:
        print("Falha na consulta dos ativos", error)
    finally:
        conexao.fecharConexao(conn)
    return ativos 

def getAllComplete():
    try:
        ativos = []
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        cursor.execute(SCRIPT_CONSULTA_COMPLETA)
        for linha in cursor.fetchall():
            print(linha[6], linha[5])
            ativos.append(PortifolioCompleto(linha[0], linha[1], linha[2], linha[3],linha[7], linha[4],None, None, None, linha[6], linha[5], None,None))
        cursor.close()
    except sqlite3.Error as error:
        print("Falha na consulta do portifolio", error)
    finally:
        conexao.fecharConexao(conn)
    return ativos     

def getAllPorCorreta(codigoCorretora):
    try:
        ativos = []
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        script = SCRIPT_CONSULTA_POR_CORRETORA.replace("filtro", str.upper(codigoCorretora))
        print(script)
        cursor.execute(script)
        for linha in cursor.fetchall():
            print(linha[6], linha[5])
            ativos.append(PortifolioCompleto(linha[0], linha[1], linha[2], linha[3],linha[7], linha[4],None, None, None, linha[6], linha[5], None,None))
        cursor.close()
    except sqlite3.Error as error:
        print("Falha na consulta do portifolio", error)
    finally:
        conexao.fecharConexao(conn)
    return ativos   



def updateValorMercado(valorMercado: float, codigo: str):
    print("debug",codigo, valorMercado)
    try:
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        script = SCRIPT_UPDATE_VALOR_MERCADO.replace("filtro", codigo).replace("valorMercado",format(valorMercado, '.2f'))
        print(script)
        cursor.execute(script)  
        conn.commit()
        cursor.close()
        print(f'Registro codigo {codigo} atualizado com sucesso')
    except sqlite3.Error as error:
        print(f'Falha ao atualizar o Portifolio {codigo}.', error)
    finally:
        conexao.fecharConexao(conn) 