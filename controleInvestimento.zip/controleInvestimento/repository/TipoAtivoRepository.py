from repository import Conexao as conexao
import sqlite3
from entity.TipoAtivo import TipoAtivo

SCRIPT_SELECT_ALL = "SELECT CODIGO, NOME,  DATA_CRIACAO FROM TIPO_ATIVO"


def getAll():
    try:
        ativos = []
        conn = conexao.abrirConexao()
        cursor = conn.cursor()
        cursor.execute(SCRIPT_SELECT_ALL)
        for linha in cursor.fetchall():
            ativos.append(TipoAtivo(linha[0], linha[1], linha[2]))
        cursor.close()
    except sqlite3.Error as error:
        print("Falha na consulta dos TipoAtivo", error)
    finally:
        conexao.fecharConexao(conn)
    return ativos                 